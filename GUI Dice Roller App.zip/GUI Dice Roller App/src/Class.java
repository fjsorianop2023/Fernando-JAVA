import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import java.util.Random;


public class Class {

    @FXML
    private ImageView Dado;
    Random random = new Random();

    @FXML
    void Correr(ActionEvent event) {
    int cara = random.nextInt(6) + 1;
    if (cara == 1){
        Dado.setImage(new Image("cara1.png"));
    }
    else if (cara == 2){
        Dado.setImage(new Image("cara2.png"));
    }
    else if (cara == 3){
        Dado.setImage(new Image("cara3.png"));
    }
    else if (cara == 4){
        Dado.setImage(new Image("cara4.png"));
    }
    else if (cara == 5){
        Dado.setImage(new Image("cara5.png"));
    }
    else if (cara == 6){
        Dado.setImage(new Image("cara6.png"));
    }

    }

}
